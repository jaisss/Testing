﻿using GraphQL;
using GraphQL.Client.Http;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Sample_PaySlip.Helpers
{
    public class HelperMethods
    {

        public static string encodeGraphPayload(string payload)
        {
            return JsonConvert.ToString(payload);
        }

        public static string GetAuthorizationCode()
        {
            string authCode = "";

            return authCode;
        }
        public static string GetAuthURL()
        {
            string authorizationRequest = string.Format("{0}?client_id={1}&response_type=code&scope={2}&redirect_uri={3}&state={4}",
               "https://appcenter-stage.intuit.com/app/connect/oauth2",
               "ABr2KX3jdCqBjhbB2JYZld9sG2KocuQqjsnKkERO251U2qSpGi",
               Uri.EscapeDataString("com.intuit.quickbooks.payroll.payslip.read"),
               Uri.EscapeDataString("https://developer-stage.intuit.com/v2/OAuth2Playground/RedirectUrl"),
               "123456");
            return authorizationRequest;
        }
        public static string GenerateAccessToken()
        {
            var client = new RestClient("https://oauth-e2e.platform.intuit.com/oauth2/v1/tokens/bearer");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/x-www-form-urlencoded");
            request.AddParameter("application/x-www-form-urlencoded", "grant_type=authorization_code" +
                "&client_id=ABr2KX3jdCqBjhbB2JYZld9sG2KocuQqjsnKkERO251U2qSpGi" +
                "&client_secret=Sjcd352RRiPDFu8qbeXh46d8vaerIizblcQWVnXJ" +
                "&code=" +
                "&redirect_url=", ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            return response.Content;
        }



    }
}
