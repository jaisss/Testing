﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Sample_PaySlip.Helpers;
using Sample_PaySlip.Models;

namespace Sample_PaySlip.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration _configuration;
        public HomeController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public IActionResult Index()
        {
            var companyNameQuery = System.IO.File.ReadAllText(@"Queries\ReadCompanyName.graphql");
            Task<string> companyNameQueryRes = GetData(companyNameQuery);
            ViewData["CompanyInfo"] = companyNameQueryRes.Result;

            var employeeNamesQuery = System.IO.File.ReadAllText(@"Queries\ReadAllEmployees.graphql");
            Task<string> employeeNamesQueryRes = GetData(employeeNamesQuery);
            ViewData["EmployeesInfo"] = employeeNamesQueryRes.Result;

            var paySlipsQuery = System.IO.File.ReadAllText(@"Queries\ReadAllPaySlips.graphql");
            Task<string> paySlipsQueryRes = GetData(paySlipsQuery);
            ViewData["PayslipsInfo"] = paySlipsQueryRes.Result;

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        async Task<string> GetData(string query)
        {
            var httpResponseContent = "";
            ///var response = new ResponseClass();
            try
            {
                HttpClient httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + _configuration.GetValue<string>("ConnectionSettings:AccessToken"));
                 //  var variables = System.IO.File.ReadAllText(@"GraphQL\inputvariables.graphql");
                //     var content = $"{{\"query\":{HelperMethods.encodeGraphPayload(graphQl)},\"variables\":{HelperMethods.encodeGraphPayload(variables)}}}";
                var content = $"{{\"query\":{HelperMethods.encodeGraphPayload(query)}}}";
                var httpContent = new StringContent(content, Encoding.UTF8, "application/json");
                string endpoint = _configuration.GetValue<string>("ConnectionSettings:EndpointURL");
                var httpResponse = await httpClient.PostAsync(endpoint, httpContent);
                httpResponseContent = await httpResponse.Content.ReadAsStringAsync();
              //  response = Newtonsoft.Json.JsonConvert.DeserializeObject<ResponseClass>(httpResponseContent);

            }
            catch (Exception ex)
            {
                throw null;
            }
            return httpResponseContent;
        }
    }
}
