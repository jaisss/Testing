﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Sample_PaySlip.Models
{
    public class ResponseClass
    {
        public Data data { get; set; }

    }

    public class Data
    {
        public Company company { get; set; }
    }

    public class Company
    {
        public Employer employer { get; set; }
    }

    public class Employer
    {
        public Employees employees { get; set; }
    }

    public class Employees
    {
        public PageInfo pageInfo { get; set; }
        public List<Nodes> nodes { get; set; }
    }

    public class Nodes
    {
        public string id { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public List<Payslips> payslips { get; set; }
    }

    public class Payslips
    {

    }

    public class PageInfo
    {
        public bool hasNextPage { get; set; }
        public string startCursor { get; set; }
        public string endCursor { get; set; }
    }
}
